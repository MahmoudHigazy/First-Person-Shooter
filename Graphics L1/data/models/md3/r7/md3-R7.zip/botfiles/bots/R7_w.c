//===========================================================================
//
// Name:			R7_w.c
// Function:		
// Programmer:		
// Last update:		
// Tab Size:		4 (real tabs)
//===========================================================================


#include "inv.h"

#define W_GAUNTLET				50
#define W_SHOTGUN				85
#define W_MACHINEGUN			30
#define W_GRENADELAUNCHER		40
#define W_ROCKETLAUNCHER		300
#define W_RAILGUN				150
#define W_BFG10K				150
#define W_LIGHTNING				100
#define W_PLASMAGUN				200
#define W_GRAPPLE				15

//
#include "fw_weap.c"
